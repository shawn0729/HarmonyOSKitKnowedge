

说明



-      本模块首批接口从API version 6开始支持。后续版本的新增接口，采用上角标单独标记接口的起始版本。

-      针对系统能力SystemCapability.Window.SessionManager，请先使用[canIUse()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/js-apis-syscap#caniuse)接口判断当前设备是否支持此syscap及对应接口。





## Configuration9+



创建子窗口或系统窗口时的参数。



**元服务API：** 从API version 12开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| name | string | 否 | 否 | <br>窗口名称。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| windowType | [WindowType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#windowtype7) | 否 | 否 | <br>窗口类型。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| ctx | [BaseContext](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/js-apis-inner-application-basecontext) | 否 | 是 | <br>当前应用上下文信息。不设置，则默认为空。<br>FA模型下不需要使用该参数，即可创建子窗口，使用该参数时会报错。<br>Stage模型必须使用该参数，用于创建全局悬浮窗、模态窗或系统窗口。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| displayId | number | 否 | 是 | <br>当前屏幕ID。不设置，则默认为-1，跟随父窗口，该参数应为整数。<br>设置后对屏幕ID进行校验，小于0或屏幕ID不存在时，返回401错误码。<br>扩展屏、异源虚拟屏场景下，全局悬浮窗可通过设置屏幕ID显示在指定屏幕上。<br>模态窗、系统窗设置屏幕ID无效，默认跟随父窗口。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| parentId | number | 否 | 是 | <br>父窗口ID。不设置，则默认为-1，默认父窗为当前应用上下文对应主窗，该参数应为整数。<br>FA模型下，对传入父窗口ID进行校验，小于0或父窗口ID不存在时，返回1300009错误码。<br>Stage模型下，该参数设置无效。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| decorEnabled12+ | boolean | 否 | 是 | <br>是否显示窗口装饰，仅在windowType为TYPE_DIALOG时生效。true表示显示，false表示不显示。此参数默认值为false。<br>**系统能力：** SystemCapability.Window.SessionManager |
| title12+ | string | 否 | 是 | <br>decorEnabled属性设置为true时，窗口的标题内容。标题显示区域最右端不超过系统三键区域最左端，超过部分以省略号表示。不设置，则默认为空字符串。<br>**系统能力：** SystemCapability.Window.SessionManager |





## SystemBarProperties



状态栏属性。



**元服务API：** 从API version 12开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| statusBarColor | string | 否 | 是 | <br>状态栏背景颜色。作为入参时格式为十六进制RGB或ARGB颜色，不区分大小写，例如'#00FF00'或'#FF00FF00'；作为返回值时格式固定为ARGB颜色，如'#FF00FF00'，默认值为系统配置的颜色。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| isStatusBarLightIcon7+ | boolean | 否 | 是 | <br>状态栏图标是否为高亮状态。true表示高亮；false表示不高亮。默认值：false。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| statusBarContentColor8+ | string | 否 | 是 | <br>状态栏文字颜色。当设置此属性后，isStatusBarLightIcon属性设置无效。默认值：'#E5FFFFFF'。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| navigationBarColor | string | 否 | 是 | <br>三键导航栏背景颜色。作为入参时格式为十六进制RGB或ARGB颜色，不区分大小写，例如'#00FF00'或'#FF00FF00'；作为返回值时格式固定为ARGB颜色，如'#FF00FF00'，默认值为系统配置的颜色。<br>HarmonyOS各设备不支持此能力。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| isNavigationBarLightIcon7+ | boolean | 否 | 是 | <br>三键导航栏图标是否为高亮状态。true表示高亮；false表示不高亮。默认值：false。<br>HarmonyOS各设备不支持此能力。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| navigationBarContentColor8+ | string | 否 | 是 | <br>三键导航栏文字颜色。当设置此属性后，isNavigationBarLightIcon属性设置无效。默认值：'#E5FFFFFF'。<br>HarmonyOS各设备不支持此能力。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| enableStatusBarAnimation12+ | boolean | 否 | 是 | <br>是否启用状态栏属性变化时的动画效果。true表示启用；false表示不启用。默认值：false。<br>**系统能力：** SystemCapability.Window.SessionManager |
| enableNavigationBarAnimation12+ | boolean | 否 | 是 | <br>是否启用三键导航栏属性变化时的动画效果。true表示启用；false表示不启用。默认值：false。<br>HarmonyOS各设备不支持此能力。<br>**系统能力：** SystemCapability.Window.SessionManager |





## StatusBarProperty18+



状态栏的属性。在获取状态栏属性信息时返回。



**元服务API：** 从API version 18开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| contentColor | string | 否 | 否 | <br>状态栏文字颜色，固定为ARGB格式，如：#E5FFFFFF。<br>**系统能力：** SystemCapability.Window.SessionManager |





## SystemBarStyle12+



状态栏的属性。在设置页面级状态栏属性时使用。



**元服务API：** 从API version 12开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.WindowManager.WindowManager.Core





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| statusBarContentColor | string | 否 | 是 | 状态栏文字颜色。默认值：'#E5FFFFFF'。 |





## FrameMetrics22+



帧率指标。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| firstDrawFrame | boolean | 否 | 否 | 是否是首帧。true表示首帧，false表示非首帧。 |
| inputHandlingDuration | number | 否 | 否 | 一帧中的手势处理耗时（单位：纳秒）。 |
| layoutMeasureDuration | number | 否 | 否 | 一帧中的布局测量耗时（单位：纳秒）。 |
| vsyncTimestamp | number | 否 | 否 | 当前帧的开始时间戳（单位：纳秒）。 |





## Rect7+



窗口矩形区域。



**系统能力：** SystemCapability.WindowManager.WindowManager.Core



**元服务API：** 从API version 11开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| left | number | 否 | 否 | 矩形区域的左边界，单位为px，该参数为整数。 |
| top | number | 否 | 否 | 矩形区域的上边界，单位为px，该参数应为整数。 |
| width | number | 否 | 否 | 矩形区域的宽度，单位为px，该参数应为整数。 |
| height | number | 否 | 否 | 矩形区域的高度，单位为px，该参数应为整数。 |





## RectInVP23+



窗口矩形区域，单位为vp。



**模型约束：** 此接口仅可在Stage模型下使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| left | number | 否 | 否 | 矩形区域的左边界值，单位为vp。 |
| top | number | 否 | 否 | 矩形区域的上边界值，单位为vp。 |
| width | number | 否 | 否 | 矩形区域的宽度，单位为vp。 |
| height | number | 否 | 否 | 矩形区域的高度，单位为vp。 |





## AvoidArea7+



窗口内容的避让区域。



窗口内容做[沉浸式布局](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E6%B2%89%E6%B5%B8%E5%BC%8F%E5%B8%83%E5%B1%80)适配时，需要按照[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)对应的AvoidArea做窗口内容避让。



在避让区域内，应用窗口内容被遮挡且无法响应用户点击事件。



**系统能力：** SystemCapability.WindowManager.WindowManager.Core



**元服务API：** 从API version 11开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| visible9+ | boolean | 否 | 否 | 无实际意义，暂不支持使用。 |
| leftRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 中心位于窗口的两条对角线的左侧的矩形区。 |
| topRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 中心位于窗口的两条对角线的顶部的矩形区。 |
| rightRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 中心位于窗口的两条对角线的右侧的矩形区。 |
| bottomRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 中心位于窗口的两条对角线的底部的矩形区。 |



说明



示意图展示了leftRect、topRect、rightRect、bottomRect的含义。



![](https://contentcenter-vali-drcn.dbankcdn.cn/pvt_2/DeveloperAlliance_scene_100_1/47/v3/o3Zhz2szShS2lwCjb567kg/zh-cn_image_0000002572302280.png?HW-CC-KV=V1&amp;HW-CC-Date=20260514T125007Z&amp;HW-CC-Expire=86400&amp;HW-CC-Sign=42AE874764D0C4BE60DD29F0EB3E56F89AC00937198CE810D7BF456C3CB81154)





## UIEnvAvoidAreaVP23+



以vp为单位表示的窗口避让区域信息，在进行[沉浸式布局](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E6%B2%89%E6%B5%B8%E5%BC%8F%E5%B8%83%E5%B1%80)适配时需关注。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| visible | boolean | 否 | 否 | 无实际意义，暂不支持使用。 |
| leftRect | [RectInVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rectinvp23) | 否 | 否 | 中心位于窗口的两条对角线的左侧的矩形区，单位为vp。 |
| topRect | [RectInVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rectinvp23) | 否 | 否 | 中心位于窗口的两条对角线的顶部的矩形区，单位为vp。 |
| rightRect | [RectInVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rectinvp23) | 否 | 否 | 中心位于窗口的两条对角线的右侧的矩形区，单位为vp。 |
| bottomRect | [RectInVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rectinvp23) | 否 | 否 | 中心位于窗口的两条对角线的底部的矩形区，单位为vp。 |





## UIEnvWindowAvoidAreaInfoPX23+



窗口不同类型避让区域信息组成的[环境变量](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/arkts-env-system-property)数据类型，每种类型避让区域单位为px。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| statusBar | [AvoidArea](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#avoidarea7) | 否 | 否 | 表示[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)为TYPE_SYSTEM类型的避让区域，单位为px。 |
| cutout | [AvoidArea](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#avoidarea7) | 否 | 否 | 表示[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)为TYPE_CUTOUT类型的避让区域，单位为px。 |
| keyboard | [AvoidArea](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#avoidarea7) | 否 | 否 | 表示[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)为TYPE_KEYBOARD类型的避让区域，单位为px。 |
| navigationIndicator | [AvoidArea](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#avoidarea7) | 否 | 否 | 表示[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)为TYPE_NAVIGATION_INDICATOR类型的避让区域，单位为px。 |





## UIEnvWindowAvoidAreaInfoVP23+



窗口不同类型避让区域信息组成的[环境变量](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/arkts-env-system-property)数据类型，每种类型避让区域单位为vp。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| statusBar | [UIEnvAvoidAreaVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#uienvavoidareavp23) | 否 | 否 | 表示[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)为TYPE_SYSTEM类型的避让区域，单位为vp。 |
| cutout | [UIEnvAvoidAreaVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#uienvavoidareavp23) | 否 | 否 | 表示[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)为TYPE_CUTOUT类型的避让区域，单位为vp。 |
| keyboard | [UIEnvAvoidAreaVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#uienvavoidareavp23) | 否 | 否 | 表示[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)为TYPE_KEYBOARD类型的避让区域，单位为vp。 |
| navigationIndicator | [UIEnvAvoidAreaVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#uienvavoidareavp23) | 否 | 否 | 表示[AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7)为TYPE_NAVIGATION_INDICATOR类型的避让区域，单位为vp。 |





## Size7+



窗口大小，单位为px。



**系统能力：** SystemCapability.WindowManager.WindowManager.Core



**元服务API：** 从API version 11开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| width | number | 否 | 否 | 窗口宽度，单位为px，该参数应为整数。 |
| height | number | 否 | 否 | 窗口高度，单位为px，该参数应为整数。 |





## SizeInVP23+



窗口大小，单位为vp。



**模型约束：** 此接口仅可在Stage模型下使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| width | number | 否 | 否 | 窗口宽度，单位为vp，该参数为浮点数。 |
| height | number | 否 | 否 | 窗口高度，单位为vp，该参数为浮点数。 |





## Position20+



窗口或组件的位置。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| x | number | 否 | 否 | x坐标，单位为px，该参数应为整数。 |
| y | number | 否 | 否 | y坐标，单位为px，该参数应为整数。 |





## RectChangeOptions12+



窗口矩形（窗口位置及窗口大小）变化返回的值及变化原因。



**系统能力：** SystemCapability.Window.SessionManager



**元服务API：** 从API version 12开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| rect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 窗口矩形变化后的值。 |
| reason | [RectChangeReason](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#rectchangereason12) | 否 | 否 | 窗口矩形变化的原因。 |





## AvoidAreaOptions12+



系统避让区变化后返回当前避让区域以及避让区域类型。



**系统能力：** SystemCapability.WindowManager.WindowManager.Core



**元服务API：** 从API version 12开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| type | [AvoidAreaType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#avoidareatype7) | 否 | 否 | 系统避让区变化后返回的避让区域类型。 |
| area | [AvoidArea](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#avoidarea7) | 否 | 否 | 系统避让区变化后返回的避让区域。 |





## WindowProperties



窗口属性。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| windowRect7+ | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | <br>窗口尺寸，其中左边界上边界是相对于窗口所在屏幕左上顶点计算，可在页面生命周期[onPageShow](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/ts-custom-component-lifecycle#onpageshow)或应用生命周期[onForeground](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/js-apis-app-ability-uiability#onforeground)阶段获取。<br>**元服务API：** 从API version 11开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| drawableRect11+ | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | <br>窗口内的可绘制区域尺寸，其中左边界上边界是相对于窗口左上顶点计算。在Stage模型下，需要在调用[loadContent()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#loadcontent9)或[setUIContent()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#setuicontent9)加载页面内容后获取该属性。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| type7+ | [WindowType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#windowtype7) | 否 | 否 | <br>窗口类型。<br>当前存在主窗使用[getWindowProperties()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#getwindowproperties9)接口返回type不准确的问题，开发者在创建窗口时已指明窗口类型，无需通过getWindowProperties()接口获取窗口类型。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| isFullScreen | boolean | 否 | 否 | <br>在满足isLayoutFullScreen为true的条件下如果隐藏了状态栏，返回值为true，其他情况下均返回false。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| isLayoutFullScreen7+ | boolean | 否 | 否 | <br>对于子窗，如果设置了[沉浸式布局](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E6%B2%89%E6%B5%B8%E5%BC%8F%E5%B8%83%E5%B1%80)，返回值为true。<br>对于主窗，如果设置了[沉浸式布局](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E6%B2%89%E6%B5%B8%E5%BC%8F%E5%B8%83%E5%B1%80)且处于全屏模式，返回值为true。<br>其他情况下均返回false<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| focusable7+ | boolean | 否 | 否 | <br>窗口是否可获焦。true表示可获焦；false表示不可获焦。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| touchable7+ | boolean | 否 | 否 | <br>窗口是否可触摸。true表示可触摸；false表示不可触摸。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| brightness | number | 否 | 否 | <br>窗口亮度。通过[setWindowBrightness()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#setwindowbrightness9)设置窗口的亮度值。该参数为浮点数，可设置的亮度范围为[0.0, 1.0]或-1.0，其取值1.0时表示最大亮度，取值-1.0时，表示亮度跟随系统。如果窗口没有设置亮度值，表示亮度跟随系统，此时获取到的亮度值为-1.0。<br>**元服务API：** 从API version 11开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| dimBehindValue(deprecated) | number | 否 | 否 | <br>下层窗口的暗度值。该参数为浮点数，取值范围为[0.0, 1.0]，其取1.0表示最暗。<br>**说明：** 从API version 7开始支持，从API version 9开始废弃，当前无可替代接口。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| isKeepScreenOn | boolean | 否 | 否 | <br>屏幕是否常亮。true表示常亮；false表示不常亮。<br>**元服务API：** 从API version 11开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| isPrivacyMode7+ | boolean | 否 | 否 | <br>窗口是否为隐私模式。true表示窗口为隐私模式；false表示窗口为非隐私模式。可通过[setWindowPrivacyMode()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#setwindowprivacymode9)设置窗口的隐私模式。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| isRoundCorner(deprecated) | boolean | 否 | 否 | <br>窗口是否为圆角。true表示窗口为圆角；false表示窗口为非圆角。<br>**说明：** 从API version 7开始支持，从API version 9开始废弃，当前无可替代接口。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| isTransparent7+ | boolean | 否 | 否 | <br>窗口背景是否透明。true表示透明；false表示不透明。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| id9+ | number | 否 | 否 | <br>窗口ID，该参数为整数。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| displayId12+ | number | 否 | 是 | <br>窗口所在屏幕ID，默认返回主屏幕ID，该参数为整数。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| name18+ | string | 否 | 是 | <br>窗口名称，默认为空字符串。<br>**元服务API：** 从API version 18开始，该接口支持在元服务中使用。<br>**系统能力：** SystemCapability.WindowManager.WindowManager.Core |
| globalDisplayRect20+ | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 是 | <br>全局坐标系下的窗口尺寸。扩展屏场景下以主屏左上角为坐标原点，虚拟屏场景下以虚拟屏左上角为坐标原点。默认值：[0, 0, 0, 0]。<br>**系统能力：** SystemCapability.Window.SessionManager |





## DecorButtonStyle14+



系统装饰栏按钮样式。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| colorMode | [ConfigurationConstant.ColorMode](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/js-apis-app-ability-configurationconstant#colormode) | 否 | 是 | <br>颜色模式。深色模式下按钮颜色适配为浅色，浅色模式下按钮颜色适配为深色。未设置则默认跟随系统颜色模式。<br>**元服务API：** 从API version 14开始，该接口支持在元服务中使用。 |
| buttonBackgroundSize | number | 否 | 是 | <br>按钮高亮显示时的大小，取值范围20vp-40vp，默认值28vp。<br>**元服务API：** 从API version 14开始，该接口支持在元服务中使用。 |
| spacingBetweenButtons | number | 否 | 是 | <br>按钮间距，取值范围8vp-24vp，默认值12vp。<br>**元服务API：** 从API version 14开始，该接口支持在元服务中使用。 |
| closeButtonRightMargin | number | 否 | 是 | <br>关闭按钮右侧距窗口边距，取值范围6vp-22vp，默认值20vp。<br>**元服务API：** 从API version 14开始，该接口支持在元服务中使用。 |
| buttonIconSize20+ | number | 否 | 是 | <br>按键icon的大小，取值范围16vp-24vp，默认值20vp。<br>**元服务API：** 从API version 20开始，该接口支持在元服务中使用。 |
| buttonBackgroundCornerRadius20+ | number | 否 | 是 | <br>按键背板圆角半径，取值范围4vp-8vp，默认值4vp。<br>**元服务API：** 从API version 20开始，该接口支持在元服务中使用。 |





## WindowLimits11+



窗口尺寸限制参数，应用可以通过[getWindowLimits](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#getwindowlimits11)获得当前窗口的尺寸限制（单位为px）；从API version 22开始，还可以通过[getWindowLimitsVP](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#getwindowlimitsvp22)获取窗口尺寸限制（单位为vp）。



窗口尺寸限制的最终生效结果由默认系统限制、应用配置和运行时设置的数据取交集得到，优先级从高到低依次为：



1. 应用通过[setWindowLimits](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#setwindowlimits11)设置窗口尺寸限制。
2. 应用在[startAbility](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/js-apis-inner-application-uiabilitycontext#startability-2)拉起窗口时通过[StartOptions](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/js-apis-app-ability-startoptions#startoptions)指定窗口尺寸限制（API version 17开始支持）。
3. 应用在[module.json5配置文件中的abilities标签](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/module-configuration-file#abilities%E6%A0%87%E7%AD%BE)中配置windowLimits。
4. 默认系统限制（基于不同产品和窗口类型，其windowLimits系统默认限制存在差异）。


**系统能力：** SystemCapability.Window.SessionManager



说明



针对maxWidth、maxHeight、minWidth、minHeight属性：



- 默认单位为px，从API version 22开始支持通过pixelUnit设置单位为px或vp。
- 参数为整数，浮点数会向下取整。
- 默认值为0，表示属性不发生变化。
- 可生效范围下限值：系统限定的最小高度/宽度。
- 可生效范围上限值：系统限定的最大高度/宽度。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| maxWidth | number | 否 | 是 | <br>窗口的最大宽度。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。 |
| maxHeight | number | 否 | 是 | <br>窗口的最大高度。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。 |
| minWidth | number | 否 | 是 | <br>窗口的最小宽度。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。 |
| minHeight | number | 否 | 是 | <br>窗口的最小高度。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。 |
| pixelUnit22+ | [PixelUnit](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#pixelunit22) | 否 | 是 | 窗口尺寸限制的单位，默认为px。可显式设置为px或vp。 |





## TitleButtonRect11+



标题栏上的最小化、最大化、关闭按钮矩形区域，该区域位置坐标相对窗口右上角。



**元服务API：** 从API version 12开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| right | number | 否 | 否 | 矩形区域的右边界，单位为vp，该参数为整数。 |
| top | number | 否 | 否 | 矩形区域的上边界，单位为vp，该参数为整数。 |
| width | number | 否 | 否 | 矩形区域的宽度，单位为vp，该参数为整数。 |
| height | number | 否 | 否 | 矩形区域的高度，单位为vp，该参数为整数。 |





## MoveConfiguration15+



窗口移动选项。



**元服务API：** 从API version 15开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| displayId | number | 否 | 是 | 目标屏幕ID，该参数应为整数，输入非整数时将向下取整。默认值为undefined。填入该参数时，将移动到相对于目标屏幕左上角的指定位置。仅支持主屏和扩展屏。此参数不传、传undefined或传入目标屏幕ID不存在时，将移动到相对于当前屏幕左上角的指定位置。 |





## WindowDensityInfo15+



窗口所在显示设备和窗口自定义的显示密度信息，是与像素单位无关的缩放系数，即显示大小缩放系数。



**元服务API：** 从API version 15开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| systemDensity | number | 否 | 否 | 窗口所在屏幕的系统显示大小缩放系数，跟随用户设置变化，该参数变化范围为0.5-4.0。 |
| defaultDensity | number | 否 | 否 | 窗口所在屏幕的系统默认显示大小缩放系数，跟随窗口所在屏幕变化，该参数变化范围为0.5-4.0。 |
| customDensity | number | 否 | 否 | 窗口自定义设置的显示大小缩放系数，该参数取值范围为0.5-4.0。未设置该参数时，将跟随系统显示大小缩放系数变化。该参数仅主窗口生效，在子窗、模态窗、全局悬浮窗或系统窗口上等于系统显示大小缩放系数(systemDensity)。 |





## WindowLayoutInfo15+



窗口布局信息。



**元服务API：** 从API version 15开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| windowRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 窗口尺寸，窗口在屏幕上的实际位置和大小。 |





## KeyboardInfo18+



软键盘窗口信息。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| beginRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | <br>动画开始前软键盘的位置和大小。<br>**元服务API：** 从API version 18开始，该接口支持在元服务中使用。 |
| endRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | <br>动画结束后软键盘的位置和大小。<br>**元服务API：** 从API version 18开始，该接口支持在元服务中使用。 |
| animated20+ | boolean | 否 | 是 | <br>当前是否有显示/隐藏动画，true表示有动画，false表示没有。<br>**元服务API：** 从API version 20开始，该接口支持在元服务中使用。 |
| config20+ | [WindowAnimationConfig](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#windowanimationconfig20) | 否 | 是 | <br>动画配置信息。<br>**元服务API：** 从API version 20开始，该接口支持在元服务中使用。 |





## ShowWindowOptions20+



显示子窗口或系统窗口时的参数。



**系统能力：** SystemCapability.Window.SessionManager



**元服务API：** 从API version 20开始，该接口支持在元服务中使用。





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| focusOnShow | boolean | 否 | 是 | 窗口调用[showWindow()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#showwindow20)显示时是否自动获焦，默认为true。该参数对主窗、模态窗、dialog窗口不生效。 |





## WindowAnimationConfig20+



窗口动画参数配置。



**元服务API：** 从API version 20开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| curve | [WindowAnimationCurve](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#windowanimationcurve20) | 否 | 否 | 动画曲线类型。 |
| duration | number | 否 | 是 | <br>动画播放的时长，单位毫秒（ms）。<br>默认值：0，最大值：3000。<br>根据动画曲线类型决定是否必填。 |
| param | [WindowAnimationCurveParam](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-t#windowanimationcurveparam20) | 否 | 是 | 动画曲线参数，根据动画曲线类型决定是否必填。 |





## WindowInfo18+



当前窗口的详细信息。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| rect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 窗口尺寸。 |
| bundleName | string | 否 | 否 | 应用Bundle的名称。 |
| abilityName | string | 否 | 否 | Ability的名称。 |
| windowId | number | 否 | 否 | 窗口ID。 |
| windowStatusType | [WindowStatusType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#windowstatustype11) | 否 | 否 | 窗口模式枚举。 |
| isFocused | boolean | 否 | 是 | 窗口是否获焦。true表示窗口获焦；false表示窗口未获焦。返回值与[isFocused()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#isfocused12)接口一致。 |
| globalDisplayRect20+ | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 是 | 全局坐标系下的窗口尺寸，其中的宽高是未经缩放计算过的原始值。扩展屏场景下以主屏左上角为坐标原点，虚拟屏场景下以虚拟屏左上角为坐标原点。默认值：[0, 0, 0, 0]。 |





## TransitionAnimation20+



窗口转场动画配置。



**元服务API：** 从API version 20开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| config | [WindowAnimationConfig](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#windowanimationconfig20) | 否 | 否 | 本次转场动画配置。 |
| opacity | number | 否 | 是 | 不透明度，转场动画作用的窗口属性，值为0时窗口完全透明，默认值为1.0。当动画类型为WindowTransitionType.DESTROY时，代表动画终点的不透明度。取值范围0~1.0，在动画结束时恢复为1.0。 |





## StartAnimationParams20+



启动动画配置。



仅对同应用的不同ability间跳转生效。



仅对全屏应用生效。



**设备行为差异：** 该接口在Phone设备的非[自由多窗模式](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E8%87%AA%E7%94%B1%E5%A4%9A%E7%AA%97%E6%A8%A1%E5%BC%8F)、Tablet设备的非[自由多窗模式](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E8%87%AA%E7%94%B1%E5%A4%9A%E7%AA%97%E6%A8%A1%E5%BC%8F)且非电脑模式下可正常调用，在其他设备、[自由多窗模式](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E8%87%AA%E7%94%B1%E5%A4%9A%E7%AA%97%E6%A8%A1%E5%BC%8F)或电脑模式下调用不生效也不报错。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| type | [AnimationType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#animationtype20) | 否 | 否 | 窗口动画类型。 |





## WindowCreateParams20+



应用启动时的窗口参数配置。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| animationParams | [StartAnimationParams](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#startanimationparams20) | 否 | 是 | 启动动画参数配置。默认值为undefined，若不配置将保持系统默认动效。 |
| needAnimation23+ | boolean | 否 | 是 | <br>是否启用窗口创建动效。<br>传入true时，跟随系统默认动效。传入false时，表示关闭窗口创建动效，仅在[自由窗口状态](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E8%87%AA%E7%94%B1%E7%AA%97%E5%8F%A3)的情况下生效。<br>此参数不填时，默认为undefined，跟随系统默认动效。<br>**模型约束：** 此接口仅可在Stage模型下使用。 |





## Callback15+





### (data: T)15+



(data: T): V



通用回调函数。



开发者在使用时，可自定义data的参数类型，回调函数返回对应类型的信息。



**元服务API：** 从API version 15开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager



**参数：**





展开

| 参数名 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| data | T | 是 | 回调函数调用时需要传入T类型的参数。 |



**返回值：**





展开

| 类型 | 说明 |
| --- | --- |
| V | 回调函数需要返回V类型的返回值。 |





## RotationChangeInfo19+



窗口旋转变化时的窗口信息。



**元服务API：** 从API version 19开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| type | [RotationChangeType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#rotationchangetype19) | 否 | 否 | 窗口旋转事件类型。 |
| orientation | number | 否 | 否 | <br>窗口显示方向。<br>- 0表示竖屏。<br>- 1表示反向横屏。<br>- 2表示反向竖屏。<br>- 3表示横屏。<br>开发者在使用时，需要注意该方向与display对象的属性orientation含义不一致。 |
| displayId | number | 否 | 否 | 窗口所在屏幕Id。 |
| displayRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 窗口所在屏幕旋转后的矩形区域大小。 |





## RotationChangeResult19+



应用在窗口旋转变化时返回的信息，系统会根据此信息改变当前窗口矩形区域大小。当返回主窗口旋转变化的信息时，系统不改变主窗口的大小。



应用窗口与系统窗口大小存在限制，具体限制与相关规则可见[resize](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#resize9)。



**元服务API：** 从API version 19开始，该接口支持在元服务中使用。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| rectType | [RectType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#recttype19) | 否 | 否 | 窗口矩形区域坐标系类型。 |
| windowRect | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 否 | 相对于屏幕或父窗坐标系的窗口矩形区域信息。 |





## SubWindowOptions11+



子窗口创建参数。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| title11+ | string | 否 | 否 | <br>子窗口标题。标题显示区域最右端不超过系统三键区域最左端，超过部分以省略号表示。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。 |
| decorEnabled11+ | boolean | 否 | 否 | <br>子窗口是否显示装饰。true表示子窗口显示装饰，false表示子窗口不显示装饰。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。 |
| isModal12+ | boolean | 否 | 是 | <br>子窗口是否启用模态属性。true表示子窗口启用模态属性，false表示子窗口禁用模态属性。不设置，则默认为false。<br>**元服务API：** 从API version 12开始，该接口支持在元服务中使用。 |
| modalityType14+ | [ModalityType](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-e#modalitytype14) | 否 | 是 | <br>子窗口模态类型，仅当子窗口启用模态属性时生效。不设置，则默认为WINDOW_MODALITY。<br>**元服务API：** 从API version 14开始，该接口支持在元服务中使用。 |
| windowRect18+ | [Rect](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-i#rect7) | 否 | 是 | <br>子窗口矩形区域，其中子窗口存在大小限制，具体参考[resize()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#resize9)方法。不设置且未调用[showWindow()](https://developer.huawei.com/consumer/cn/doc/harmonyos-references/arkts-apis-window-window#showwindow9)显示前，则默认为{left: 0, top: 0, width: 0, height: 0}。具体参考[设置应用子窗口](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/application-window-stage#%E8%AE%BE%E7%BD%AE%E5%BA%94%E7%94%A8%E5%AD%90%E7%AA%97%E5%8F%A3)开发指南。<br>**元服务API：** 从API version 18开始，该接口支持在元服务中使用。 |
| zLevel18+ | number | 否 | 是 | <br>子窗口层级级别，仅当子窗口未启用模态属性，即未设置isModal时生效。该参数是整数，取值范围为[-10000, 10000]，浮点数输入将向下取整。不设置，则默认为0。<br>**元服务API：** 从API version 18开始，该接口支持在元服务中使用。 |
| maximizeSupported19+ | boolean | 否 | 是 | <br>子窗口是否支持最大化特性。true表示子窗口支持最大化，false表示子窗口不支持最大化。不设置，则默认为false。<br>**元服务API：** 从API version 19开始，该接口支持在元服务中使用。<br>**设备行为差异：** 该参数在支持并处于[自由窗口](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E8%87%AA%E7%94%B1%E7%AA%97%E5%8F%A3)状态的设备上可正常调用；在不支持[自由窗口](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E8%87%AA%E7%94%B1%E7%AA%97%E5%8F%A3)状态的设备上，作为入参使用时，对应接口不生效不报错；在支持但不处于[自由窗口](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E8%87%AA%E7%94%B1%E7%AA%97%E5%8F%A3)状态的设备上，作为入参使用时，对应接口不生效不报错，切换到[自由窗口](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/window-terminology#%E8%87%AA%E7%94%B1%E7%AA%97%E5%8F%A3)状态后生效。 |
| outlineEnabled20+ | boolean | 否 | 是 | <br>子窗口是否显示描边。true表示子窗口显示描边，false表示子窗口不显示描边。不设置，则默认为false。<br>**元服务API：** 从API version 20开始，该接口支持在元服务中使用。<br>**设备行为差异：** 该参数在2in1设备、其他设备的电脑模式中可正常调用，在其他设备和其他模式中作为入参使用时，对应接口不生效不报错。 |





## KeyFramePolicy20+



关键帧的策略配置。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| enable | boolean | 否 | 否 | 是否开启关键帧。true表示开启，false表示关闭。 |
| interval | number | 否 | 是 | 设置关键帧布局切换的拖拽时间间隔，单位为毫秒，默认值为1000。取值为正整数，浮点数向下取整。与distance判断为或的关系：满足其一即开始布局切换。 |
| distance | number | 否 | 是 | 设置关键帧布局切换的拖拽距离间隔，单位为px，默认值为1000。取值为0或正整数，浮点数向下取整。设置为0时，忽略拖拽距离因素。与interval判断为或的关系：满足其一即开始布局切换。 |
| animationDuration | number | 否 | 是 | 设置关键帧布局的动效切换时间，单位为毫秒，默认值为100。取值为0或正整数，浮点数向下取整。 |
| animationDelay | number | 否 | 是 | 设置关键帧布局切换动效延迟时间，单位为毫秒，默认值为100。取值为0或正整数，浮点数向下取整。 |





## MainWindowInfo21+



主窗口信息。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| displayId | number | 否 | 否 | 主窗口所在的屏幕ID。 |
| windowId | number | 否 | 否 | 主窗口ID。 |
| showing | boolean | 否 | 否 | 主窗口的前后台状态。true表示主窗口在前台，false表示主窗口不在前台。 |
| label | string | 否 | 否 | 主窗口的任务名称。 |





## WindowSnapshotConfiguration21+



主窗口截图的配置项。



**系统能力：** SystemCapability.Window.SessionManager





展开

| 名称 | 类型 | 只读 | 可选 | 说明 |
| --- | --- | --- | --- | --- |
| useCache | boolean | 否 | 是 | 是否使用主窗口的已有截图。默认值为true。 true表示使用主窗口的已有截图，若主窗口无保存的截图，则使用主窗口的最新截图。false表示使用主窗口的最新截图。 |
